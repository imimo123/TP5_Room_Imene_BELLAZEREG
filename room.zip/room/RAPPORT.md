# Rapport TP n°5 : Base de données locale SQLite avec Room

## 1. Introduction
Ce TP a pour objectif de mettre en œuvre une base de données locale dans une application Android en utilisant la bibliothèque Room. Room agit comme une couche d'abstraction au-dessus de SQLite, facilitant l'accès aux données et réduisant le code boilerplate.

## 2. Migration du Schéma (Question 6)

### Comment Room gère-t-il la migration ?
Lorsque la version de la base de données change (incrémentée dans l'annotation `@Database`), Room a besoin de savoir comment migrer les données existantes vers la nouvelle structure.
Room utilise des objets `Migration` qui définissent les instructions SQL à exécuter pour passer d'une version `startVersion` à une version `endVersion`.
Si aucune migration n'est fournie, Room lancera une `IllegalStateException` et l'application plantera, à moins que `fallbackToDestructiveMigration()` ne soit configuré (ce qui supprime toutes les données).

### Exemple d'implémentation (Ajout d'une colonne 'age')
Voici comment on implémente une migration pour ajouter une colonne `age` à la table `utilisateurs` lors du passage de la version 1 à 2 :

```kotlin
val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(database: SupportSQLiteDatabase) {
        // Commande SQL pour ajouter la nouvelle colonne
        database.execSQL("ALTER TABLE utilisateurs ADD COLUMN age INTEGER DEFAULT 0 NOT NULL")
    }
}

// Dans le builder de la base de données :
Room.databaseBuilder(context, AppDatabase::class.java, "base_donnees_app")
    .addMigrations(MIGRATION_1_2)
    .build()
```

## 3. Synthèse

### Principales étapes réalisées
1.  **Configuration** : Ajout des dépendances Room et Coroutines dans `build.gradle`.
2.  **Entité** : Création de la classe `Utilisateur` annotée avec `@Entity` pour définir la table.
3.  **DAO** : Création de l'interface `UtilisateurDao` avec les méthodes CRUD (`@Insert`, `@Query`, `@Delete`).
4.  **Base de données** : Création de la classe abstraite `AppDatabase` étendant `RoomDatabase` et implémentant le pattern Singleton.
5.  **Intégration** : Utilisation de la base de données dans `MainActivity` avec des coroutines (`lifecycleScope`, `Dispatchers.IO`) pour ne pas bloquer le thread principal.

### Difficultés rencontrées et solutions
*   **Asynchronisme** : Les opérations de base de données ne peuvent pas être exécutées sur le thread principal (UI thread).
    *   *Solution* : Utilisation des Coroutines Kotlin (`suspend functions` et `withContext(Dispatchers.IO)`).
*   **Configuration Gradle** : S'assurer que `kapt` est bien appliqué pour le processeur d'annotations de Room.

### Améliorations proposées
Pour enrichir l'application, nous pourrions :
*   **Architecture MVVM** : Séparer la logique de la vue en utilisant un `ViewModel` et un `Repository`.
*   **LiveData / Flow** : Observer les données de la base en temps réel (ex: `fun getAll(): Flow<List<Utilisateur>>`) pour que l'interface se mette à jour automatiquement.
*   **Injection de dépendances** : Utiliser Hilt pour injecter l'instance de la base de données.
*   **Interface Utilisateur** : Créer un formulaire pour ajouter des utilisateurs et une RecyclerView pour les afficher.

### Observations générales
Room simplifie grandement l'utilisation de SQLite sous Android. Les annotations permettent de valider les requêtes SQL à la compilation, ce qui évite de nombreuses erreurs d'exécution. L'intégration avec les Coroutines rend le code asynchrone plus lisible et séquentiel.
