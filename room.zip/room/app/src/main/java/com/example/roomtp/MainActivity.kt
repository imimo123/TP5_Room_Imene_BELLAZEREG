package com.example.roomtp

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.roomtp.data.AppDatabase
import com.example.roomtp.data.Utilisateur
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var tvResultats: TextView
    private lateinit var tvStatus: TextView
    private lateinit var btnExecuterTP: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        tvResultats = findViewById(R.id.tvResultats)
        tvStatus = findViewById(R.id.tvStatus)
        btnExecuterTP = findViewById(R.id.btnExecuterTP)


        btnExecuterTP.setOnClickListener {
            executerTPRoom()
        }


        executerTPRoom()
    }

    private fun executerTPRoom() {
        tvStatus.text = "🔄 Exécution du TP Room en cours..."
        tvResultats.text = "⏳ Initialisation de la base de données...\n\nVeuillez patienter"

        lifecycleScope.launch {
            try {
                val db = AppDatabase.getInstance(applicationContext)
                val dao = db.utilisateurDao()

                // ============ ÉTAPE 1: Nettoyage de la base ============
                tvResultats.text = "🗑️ Nettoyage des données existantes..."
                withContext(Dispatchers.IO) {
                    val usersExistants = dao.getAllUtilisateurs()
                    usersExistants.forEach { dao.supprimerUtilisateur(it) }
                }

                // ============ ÉTAPE 2: Insertion des utilisateurs ============
                tvResultats.text = "📝 Insertion des utilisateurs de test..."

                val utilisateursTest = listOf(
                    Utilisateur(nom = "Amina Bensalem", email = "amina.bensalem@esi.dz"),
                    Utilisateur(nom = "Mohamed Ali", email = "mohamed.ali@univ.dz"),
                    Utilisateur(nom = "Fatima Zohra", email = "fatima.zohra@univ.dz"),
                    Utilisateur(nom = "Khalid Ahmed", email = "khalid.ahmed@univ.dz")
                )

                withContext(Dispatchers.IO) {
                    utilisateursTest.forEach { dao.insererUtilisateur(it) }
                }

                // ============ ÉTAPE 3: Lecture des données ============
                tvResultats.text = " Lecture des données depuis la base..."
                val utilisateursDb = withContext(Dispatchers.IO) {
                    dao.getAllUtilisateurs()
                }

                // ============ ÉTAPE 4: Affichage des résultats ============
                val resultatText = buildString {
                    appendLine(" RÉSULTATS DU TP ROOM")
                    appendLine("══════════════════════════════")
                    appendLine()
                    appendLine("📊 STATISTIQUES:")
                    appendLine("   • Utilisateurs insérés: ${utilisateursTest.size}")
                    appendLine("   • Utilisateurs lus depuis DB: ${utilisateursDb.size}")
                    appendLine()

                    if (utilisateursDb.isNotEmpty()) {
                        appendLine("👥 LISTE DES UTILISATEURS:")
                        appendLine("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")

                        utilisateursDb.forEachIndexed { index, user ->
                            appendLine("Utilisateur ${index + 1}:")
                            appendLine("   🆔 ID: ${user.id}")
                            appendLine("   👤 Nom: ${user.nom}")
                            appendLine("   📧 Email: ${user.email}")
                            appendLine("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
                        }
                    }

                    appendLine()
                    appendLine("⚙️ OPÉRATIONS CRUD TESTÉES:")
                    appendLine("   1. ✅ CREATE (Insertion)")
                    appendLine("   2. ✅ READ (Lecture)")
                    appendLine("   3. ✅ DELETE (Suppression)")
                    appendLine()
                    appendLine("💡 Les données seront supprimées automatiquement dans 10 secondes...")
                }

                tvResultats.text = resultatText
                tvStatus.text = "✅ TP Room exécuté avec succès!"

                // ============ ÉTAPE 5: Suppression automatique ============
                lifecycleScope.launch {
                    kotlinx.coroutines.delay(10000) // 10 secondes

                    withContext(Dispatchers.IO) {
                        utilisateursDb.forEach { dao.supprimerUtilisateur(it) }
                    }

                    val utilisateursRestants = withContext(Dispatchers.IO) {
                        dao.getAllUtilisateurs()
                    }

                    tvResultats.append("\n\n🗑️ Données supprimées automatiquement")
                    tvResultats.append("\n📊 Utilisateurs restants: ${utilisateursRestants.size}")
                    tvStatus.text = "🗑️ Toutes les données ont été supprimées"
                }

            } catch (e: Exception) {
                // En cas d'erreur
                val erreurText = buildString {
                    appendLine("❌ ERREUR LORS DU TP ROOM")
                    appendLine("══════════════════════════════")
                    appendLine()
                    appendLine("📋 Détails de l'erreur:")
                    appendLine("   • Type: ${e.javaClass.simpleName}")
                    appendLine("   • Message: ${e.message}")
                    appendLine()
                    appendLine("🔧 Vérifiez:")
                    appendLine("   1. Les dépendances Room dans build.gradle")
                    appendLine("   2. La configuration de la base de données")
                    appendLine("   3. Les permissions de l'application")
                }

                tvResultats.text = erreurText
                tvStatus.text = "❌ Échec de l'exécution du TP"
            }
        }
    }
}