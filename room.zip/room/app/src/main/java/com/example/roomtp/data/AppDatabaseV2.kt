package com.example.roomtp.data

import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import android.content.Context

@Database(
    entities = [UtilisateurV2::class],  // استخدام Entity الجديد
    version = 2,  // زيادة الإصدار
    exportSchema = false
)
abstract class AppDatabaseV2 : RoomDatabase() {

    abstract fun utilisateurDao(): UtilisateurDaoV2

    companion object {
        @Volatile
        private var INSTANCE: AppDatabaseV2? = null

        // تعريف Migration من الإصدار 1 إلى 2
        private val MIGRATION_1_2: Migration = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
                // إضافة عمود age جديد
                database.execSQL("ALTER TABLE utilisateurs ADD COLUMN age INTEGER DEFAULT NULL")
            }
        }

        fun getInstance(context: Context): AppDatabaseV2 =
            INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabaseV2::class.java,
                    "base_donnees_app.db"
                )
                    .addMigrations(MIGRATION_1_2)  // إضافة Migration
                    .build()
                INSTANCE = instance
                instance
            }
    }
}