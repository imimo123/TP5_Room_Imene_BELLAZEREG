package com.example.roomtp.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query

@Dao
interface UtilisateurDao {

    @Query("SELECT * FROM utilisateurs")
    suspend fun getAllUtilisateurs(): List<Utilisateur>

    @Insert
    suspend fun insererUtilisateur(utilisateur: Utilisateur)

    @Delete
    suspend fun supprimerUtilisateur(utilisateur: Utilisateur)
}