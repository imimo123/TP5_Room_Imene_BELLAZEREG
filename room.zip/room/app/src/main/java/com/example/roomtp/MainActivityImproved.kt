package com.example.roomtp

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.roomtp.data.AppDatabase
import com.example.roomtp.data.Utilisateur
import com.example.roomtp.data.UtilisateurDao
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivityImproved : AppCompatActivity() {

    private lateinit var utilisateurDao: UtilisateurDao

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Log.d("TP_Room", "=== Début du TP Room ===")

        val db = AppDatabase.getInstance(applicationContext)
        utilisateurDao = db.utilisateurDao()

        // 1. إدراج مستخدم
        val utilisateur = Utilisateur(
            nom = "Amina Bensalem",
            email = "amina.bensalem@esi.dz"
        )

        lifecycleScope.launch {
            try {

                Log.d("TP_Room", "Insertion de l'utilisateur: ${utilisateur.nom}")
                insererUtilisateur(utilisateur)

                // 3. قراءة جميع المستخدمين
                Log.d("TP_Room", "Lecture des utilisateurs")
                val liste = getAllUtilisateurs()

                // 4. عرض النتائج
                Log.d("TP_Room", "=== Résultats ===")
                Log.d("TP_Room", "Nombre d'utilisateurs: ${liste.size}")
                liste.forEach { user ->
                    Log.d("TP_Room", "ID: ${user.id}, Nom: ${user.nom}, Email: ${user.email}")
                }


                Log.d("TP_Room", "Suppression des utilisateurs")
                supprimerUtilisateurs(liste)


                val listeApresSuppression = getAllUtilisateurs()
                Log.d("TP_Room", "Nombre d'utilisateurs après suppression: ${listeApresSuppression.size}")

                Log.d("TP_Room", "=== TP Terminé avec Succès ===")

            } catch (e: Exception) {
                Log.e("TP_Room", "Erreur: ${e.message}", e)
            }
        }
    }

    private suspend fun insererUtilisateur(u: Utilisateur) =
        withContext(Dispatchers.IO) {
            utilisateurDao.insererUtilisateur(u)
        }

    private suspend fun getAllUtilisateurs(): List<Utilisateur> =
        withContext(Dispatchers.IO) {
            utilisateurDao.getAllUtilisateurs()
        }

    private suspend fun supprimerUtilisateurs(us: List<Utilisateur>) =
        withContext(Dispatchers.IO) {
            us.forEach { utilisateurDao.supprimerUtilisateur(it) }
        }
}