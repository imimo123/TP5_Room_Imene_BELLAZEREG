# TP Room Database

Ce dossier contient le code source pour le TP n°5 : Base de données locale SQLite avec Room.

## Structure du projet

*   `app/src/main/java/com/example/roomtp/data/` : Contient les classes liées à Room (Entité, DAO, Database).
*   `app/src/main/java/com/example/roomtp/MainActivity.kt` : Activité principale démontrant l'utilisation.
*   `RAPPORT.md` : Réponses aux questions du TP et synthèse.

## Instructions

1.  Si vous avez déjà un projet Android, copiez les fichiers du dossier `app/src/main/java` dans votre dossier source.
2.  Ajoutez les dépendances listées dans `app/build.gradle` à votre fichier `build.gradle` existant.
3.  Synchronisez le projet avec Gradle.
4.  Lancez l'application.

## Visualisation de la base de données

Comme indiqué dans le sujet, vous pouvez utiliser **DB Browser for SQLite** pour inspecter le fichier généré sur le device/émulateur :
`/data/data/com.example.roomtp/databases/base_donnees_app`
(Utilisez l'Device File Explorer d'Android Studio pour extraire ce fichier).
