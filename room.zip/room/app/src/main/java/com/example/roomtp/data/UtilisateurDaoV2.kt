package com.example.roomtp.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update

@Dao
interface UtilisateurDaoV2 {

    @Query("SELECT * FROM utilisateurs")
    suspend fun getAllUtilisateurs(): List<UtilisateurV2>

    @Insert
    suspend fun insererUtilisateur(utilisateur: UtilisateurV2)

    @Update
    suspend fun modifierUtilisateur(utilisateur: UtilisateurV2)

    @Delete
    suspend fun supprimerUtilisateur(utilisateur: UtilisateurV2)

    @Query("SELECT * FROM utilisateurs WHERE age > :minAge")
    suspend fun getUtilisateursByAge(minAge: Int): List<UtilisateurV2>
}