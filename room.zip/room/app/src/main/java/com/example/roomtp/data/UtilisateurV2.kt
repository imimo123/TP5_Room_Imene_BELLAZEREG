package com.example.roomtp.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "utilisateurs")
data class UtilisateurV2(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val nom: String,
    val email: String,
    val age: Int? = null  // عمود جديد تمت إضافته
)